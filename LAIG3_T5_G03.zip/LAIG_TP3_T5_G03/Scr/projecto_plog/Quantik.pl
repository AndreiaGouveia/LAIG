:- consult('Menu.pl').
:- consult('display.pl').
:- consult('Logica.pl').
:- consult('Modos.pl').
:- consult('bot.pl').
:- use_module(library(lists)).
:- use_module(library(random)).

play:- menus.